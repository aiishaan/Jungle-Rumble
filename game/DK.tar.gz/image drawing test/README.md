Authors:
    Arian Safari (30161346)
    Aishan Irfan (30157743)

Game instructions:

The character must collect all coins and get to the door in the given time to pass each level.
Blue hearts grant half a heart.
Enemies (Skelettons, sharks, wolves, DK) reduce half a heart and reset character position when the character is hit
Some objects (rocks, trees, barrels) block the characters path and others (cactus, seaweed, thorns, explosive barrels) reduce half a heart and reset character position when the character hits them